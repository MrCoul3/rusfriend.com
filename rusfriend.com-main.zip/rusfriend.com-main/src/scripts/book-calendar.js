// $(document).ready(function () {
//     if ($('main').hasClass("private-lesson") || $('main').hasClass("speaking-club")) {
//         console.log('booking-calendar init');
//     }
// });
//
