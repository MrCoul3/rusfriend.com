$(document).ready(function () {
    if ($('main').hasClass("my-lessons")) {
        console.log('my lessons init');
    }

})
