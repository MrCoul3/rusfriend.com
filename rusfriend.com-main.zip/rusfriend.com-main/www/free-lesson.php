<?php
require 'pages/requires/header.php';
require("vendor/autoload.php");
?>
<title>Бесплатное занятие</title>
<main class="free-lesson">
    <div id="vue-book-calendar"></div>
</main>
<?php require 'pages/requires/footer.php' ?>
