<?php
require 'pages/requires/header.php';
require("vendor/autoload.php");
?>
<title>Курсы</title>
<main class="courses-page">
    <section class="courses">
        <div class="inner">
            <h2 switch-lang="<?=switchLang()?>" switchable-text="Здесь скоро появятся наши курсы..." class="main-title">Our courses will be available here soon...</h2>
        </div>
    </section>
</main>
<?php require 'pages/requires/footer.php' ?>
